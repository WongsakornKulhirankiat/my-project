Meun Screen  
Screen5 -> admin user  (wifi setting)  
Screen3 -> general user
