##XFace_Department_Registration
Department_Registration_textdir = {1:"Department Register", 
                                   2:"Department Name", 
                                   3:"WorkStartTime", 
                                   4:"WorkEndTime", 
                                   5:"RestTime", 
                                   6:"OverTime", 
                                   7:"Next", 
                                   8:"Error", 
                                   9:"Department name not entered!", 
                                   10:"Save", 
                                   11:"Success", 
                                   12:"Success in saving departmental information!"}